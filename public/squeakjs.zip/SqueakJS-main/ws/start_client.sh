#!/bin/sh
cd client
node ../../squeak_node.js cuis.image

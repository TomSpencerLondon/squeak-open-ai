#!/bin/sh
cd server
npm install
node index.js

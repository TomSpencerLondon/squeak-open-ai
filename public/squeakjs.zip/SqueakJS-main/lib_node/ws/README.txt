Source used from https://github.com/websockets/ws (MIT licensed)

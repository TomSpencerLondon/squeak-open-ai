// ErikOnBike
// The original code is removed since its usage might degrade performance and memory usage.
module.exports = {
  extensionName: "PerMessageDeflate"
};

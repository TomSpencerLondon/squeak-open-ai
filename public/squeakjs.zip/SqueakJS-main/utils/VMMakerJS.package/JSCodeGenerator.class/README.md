This class is a copy of CCodeGenerator hacked to generate JavaScript instead of C for use with the SqueakJS virtual machine.

C and JS semantics are pretty close except for pointers, types, and divide/modulo/shift operations. 